/** massiv cards */
const initialCards = [
  {
    name: 'Набу',
    link: 'https://kartinkin.net/uploads/posts/2021-04/thumbs/1618103152_7-p-planeta-nabu-zvezdnie-voini-fentezi-10.jpg'
  },
  {
    name: 'Джакку',
    link: 'https://i.pinimg.com/736x/2b/d7/c0/2bd7c01c02784322f682c67b7040f59f--star-destroyer-star-wars-action-figures.jpg'
  },
  {
    name: 'Арвала 7',
    link: 'https://www.jedipedia.net/w/images/8/81/Arvala7.jpg'
  },
  {
    name: 'Корусант',
    link: 'https://avatars.mds.yandex.net/get-zen_doc/4078437/pub_60450121665e4413f3e35e63_604502aa44edc6668121f0e8/scale_1200'
  },
  {
    name: 'Альдераан',
    link: 'https://i.pinimg.com/originals/bc/1c/46/bc1c464836771a88349a73a234fe7f3e.jpg'
  },
  {
    name: 'Мустафар',
    link: 'https://cutewallpaper.org/21/mustafar-background/Lava-Planet-Flytrough-Star-Wars-Mustafar-3D-Animation.jpg'
  }
];